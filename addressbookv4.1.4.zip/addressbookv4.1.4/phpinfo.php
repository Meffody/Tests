<?php

 

phpinfo();

 

?>
